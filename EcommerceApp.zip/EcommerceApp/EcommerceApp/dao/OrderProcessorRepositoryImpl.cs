﻿using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.SqlClient;
using EcommerceApp.dao;
using EcommerceApp.entity;
using EcommerceApp.exceptions;
using EcommerceApp.util;
using EcommerceApp.entity;
using EcommerceApp.exceptions;
using EcommerceApp.util;

namespace dao
{
    public class OrderProcessorRepositoryImpl : IOrderProcessorRepository
    {
        private SqlConnection conn = DBConnUtil.GetConnection();

        public bool CreateProduct(Product product)
        {
            string query = "INSERT INTO products (name, price, description, stockQuantity) VALUES (@name, @price, @description, @stockQuantity)";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@name", product.Name);
            cmd.Parameters.AddWithValue("@price", product.Price);
            cmd.Parameters.AddWithValue("@description", product.Description);
            cmd.Parameters.AddWithValue("@stockQuantity", product.StockQuantity);

            conn.Open();
            int result = cmd.ExecuteNonQuery();
            conn.Close();

            return result > 0;
        }

        public bool CreateCustomer(Customer customer)
        {
            string query = "INSERT INTO customers (name, email, password) VALUES (@name, @email, @password)";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@name", customer.Name);
            cmd.Parameters.AddWithValue("@email", customer.Email);
            cmd.Parameters.AddWithValue("@password", customer.Password);

            conn.Open();
            int result = cmd.ExecuteNonQuery();
            conn.Close();

            return result > 0;
        }

        public bool DeleteProduct(int productId)
        {
            if (!ProductExists(productId))
                throw new ProductNotFoundException($"Product with ID {productId} not found.");

            string query = "DELETE FROM products WHERE product_id=@productId";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@productId", productId);

            conn.Open();
            int result = cmd.ExecuteNonQuery();
            conn.Close();

            return result > 0;
        }

        public bool DeleteCustomer(int customerId)
        {
            if (!CustomerExists(customerId))
                throw new CustomerNotFoundException($"Customer with ID {customerId} not found.");

            string query = "DELETE FROM customers WHERE customer_id=@customerId";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@customerId", customerId);

            conn.Open();
            int result = cmd.ExecuteNonQuery();
            conn.Close();

            return result > 0;
        }

        public bool AddToCart(Customer customer, Product product, int quantity)
        {
            if (!CustomerExists(customer.CustomerId))
                throw new CustomerNotFoundException($"Customer with ID {customer.CustomerId} not found.");

            if (!ProductExists(product.ProductId))
                throw new ProductNotFoundException($"Product with ID {product.ProductId} not found.");

            string query = "INSERT INTO cart (customer_id, product_id, quantity) VALUES (@customerId, @productId, @quantity)";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@customerId", customer.CustomerId);
            cmd.Parameters.AddWithValue("@productId", product.ProductId);
            cmd.Parameters.AddWithValue("@quantity", quantity);

            conn.Open();
            int result = cmd.ExecuteNonQuery();
            conn.Close();

            return result > 0;
        }

        public bool RemoveFromCart(Customer customer, Product product)
        {
            string query = "DELETE FROM cart WHERE customer_id=@customerId AND product_id=@productId";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@customerId", customer.CustomerId);
            cmd.Parameters.AddWithValue("@productId", product.ProductId);

            conn.Open();
            int result = cmd.ExecuteNonQuery();
            conn.Close();

            return result > 0;
        }

        public List<Product> GetAllFromCart(Customer customer)
        {
            if (!CustomerExists(customer.CustomerId))
                throw new CustomerNotFoundException($"Customer with ID {customer.CustomerId} not found.");

            string query = "SELECT p.product_id, p.name, p.price, p.description, p.stockQuantity FROM products p JOIN cart c ON p.product_id = c.product_id WHERE c.customer_id=@customerId";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@customerId", customer.CustomerId);

            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            List<Product> products = new List<Product>();

            while (reader.Read())
            {
                products.Add(new Product
                {
                    ProductId = reader.GetInt32(0),
                    Name = reader.GetString(1),
                    Price = reader.GetDouble(2),
                    Description = reader.GetString(3),
                    StockQuantity = reader.GetInt32(4)
                });
            }
            conn.Close();

            return products;
        }

        public bool PlaceOrder(Customer customer, Dictionary<Product, int> productQuantities, string shippingAddress)
        {
            if (!CustomerExists(customer.CustomerId))
                throw new CustomerNotFoundException($"Customer with ID {customer.CustomerId} not found.");

            double totalPrice = 0;

            foreach (var entry in productQuantities)
            {
                if (!ProductExists(entry.Key.ProductId))
                    throw new ProductNotFoundException($"Product with ID {entry.Key.ProductId} not found.");
                totalPrice += entry.Key.Price * entry.Value;
            }

            conn.Open();
            SqlTransaction transaction = conn.BeginTransaction();

            try
            {
                string insertOrder = "INSERT INTO orders (customer_id, order_date, total_price, shipping_address) VALUES (@customerId, GETDATE(), @totalPrice, @shippingAddress); SELECT SCOPE_IDENTITY();";
                SqlCommand orderCmd = new SqlCommand(insertOrder, conn, transaction);
                orderCmd.Parameters.AddWithValue("@customerId", customer.CustomerId);
                orderCmd.Parameters.AddWithValue("@totalPrice", totalPrice);
                orderCmd.Parameters.AddWithValue("@shippingAddress", shippingAddress);

                int orderId = Convert.ToInt32(orderCmd.ExecuteScalar());

                foreach (var entry in productQuantities)
                {
                    string insertItem = "INSERT INTO order_items (order_id, product_id, quantity) VALUES (@orderId, @productId, @quantity)";
                    SqlCommand itemCmd = new SqlCommand(insertItem, conn, transaction);
                    itemCmd.Parameters.AddWithValue("@orderId", orderId);
                    itemCmd.Parameters.AddWithValue("@productId", entry.Key.ProductId);
                    itemCmd.Parameters.AddWithValue("@quantity", entry.Value);

                    itemCmd.ExecuteNonQuery();
                }

                transaction.Commit();
            }
            catch (Exception)
            {
                transaction.Rollback();
                conn.Close();
                throw;
            }

            conn.Close();
            return true;
        }

        public List<OrderItem> GetOrdersByCustomer(int customerId)
        {
            if (!CustomerExists(customerId))
                throw new CustomerNotFoundException($"Customer with ID {customerId} not found.");

            string query = "SELECT oi.order_item_id, oi.order_id, oi.product_id, oi.quantity FROM order_items oi JOIN orders o ON oi.order_id = o.order_id WHERE o.customer_id = @customerId";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@customerId", customerId);

            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            List<OrderItem> orderItems = new List<OrderItem>();

            while (reader.Read())
            {
                orderItems.Add(new OrderItem
                {
                    OrderItemId = reader.GetInt32(0),
                    OrderId = reader.GetInt32(1),
                    ProductId = reader.GetInt32(2),
                    Quantity = reader.GetInt32(3)
                });
            }
            conn.Close();

            return orderItems;
        }

        // --- Helper Methods ---
        private bool ProductExists(int productId)
        {
            string query = "SELECT COUNT(*) FROM products WHERE product_id=@productId";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@productId", productId);

            conn.Open();
            int count = (int)cmd.ExecuteScalar();
            conn.Close();

            return count > 0;
        }
        public List<Product> GetAllProducts()
        {
            string query = "SELECT product_id, name, price, description, stockQuantity FROM products";
            SqlCommand cmd = new SqlCommand(query, conn);

            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            List<Product> products = new List<Product>();

            while (reader.Read())
            {
                products.Add(new Product
                {
                    ProductId = reader.GetInt32(0),
                    Name = reader.GetString(1),
                    Price = reader.GetDouble(2),
                    Description = reader.GetString(3),
                    StockQuantity = reader.GetInt32(4)
                });
            }
            conn.Close();

            return products;
        }

        public Product GetProductByName(string productName)
        {
            string query = "SELECT product_id, name, price, description, stockQuantity FROM products WHERE name=@name";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@name", productName);

            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            Product product = null;

            if (reader.Read())
            {
                product = new Product
                {
                    ProductId = reader.GetInt32(0),
                    Name = reader.GetString(1),
                    Price = reader.GetDouble(2),
                    Description = reader.GetString(3),
                    StockQuantity = reader.GetInt32(4)
                };
            }
            conn.Close();

            if (product == null)
                throw new ProductNotFoundException($"Product with name '{productName}' not found.");

            return product;
        }

        private bool CustomerExists(int customerId)
        {
            string query = "SELECT COUNT(*) FROM customers WHERE customer_id=@customerId";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@customerId", customerId);

            conn.Open();
            int count = (int)cmd.ExecuteScalar();
            conn.Close();

            return count > 0;
        }
    }
}
