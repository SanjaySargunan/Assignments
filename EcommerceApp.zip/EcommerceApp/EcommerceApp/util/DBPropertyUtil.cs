﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;

namespace EcommerceApp.util
{
    public class DBPropertyUtil
    {
        public static string GetConnectionString(string key)
        {
            var config = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json")
                .Build();
            return config.GetConnectionString(key);
        }
    }
}
