﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace EcommerceApp.util
{
    public class DBConnUtil
    {
        private static SqlConnection connection;

        public static SqlConnection GetConnection()
        {
            if (connection == null)
            {
                string connStr = DBPropertyUtil.GetConnectionString("EcommerceDB");
                connection = new SqlConnection(connStr);
            }
            return connection;
        }
    }
}
