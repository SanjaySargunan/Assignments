﻿using EcommerceApp.app;

namespace EcommerceApp.app
{
    public class Program
    {
        public static void Main(string[] args)
        {
            EcomApp.start();
        }
    }
}
