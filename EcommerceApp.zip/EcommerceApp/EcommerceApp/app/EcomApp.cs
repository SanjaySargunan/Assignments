﻿using System;
using System.Collections.Generic;
using EcommerceApp.dao;
using EcommerceApp.entity;
using dao;
namespace EcommerceApp.app
{
    public class EcomApp
    {
        public static void start()
        {
            IOrderProcessorRepository repository = new OrderProcessorRepositoryImpl();

            while (true)
            {
                Console.WriteLine("\n=== ECOMMERCE APPLICATION ===");
                Console.WriteLine("1. Add Product");
                Console.WriteLine("2. Add Customer");
                Console.WriteLine("3. Delete Product");
                Console.WriteLine("4. Delete Customer");
                Console.WriteLine("5. Add To Cart");
                Console.WriteLine("6. View Cart");
                Console.WriteLine("7. Place Order");
                Console.WriteLine("8. View Orders by Customer");
                Console.WriteLine("9. Exit");
                Console.Write("Enter your choice: ");
                int choice = Convert.ToInt32(Console.ReadLine());

                try
                {
                    switch (choice)
                    {
                        case 1:
                            Product product = new Product();
                            Console.Write("Enter product name: ");
                            product.Name = Console.ReadLine();
                            Console.Write("Enter price: ");
                            product.Price = Convert.ToDouble(Console.ReadLine());
                            Console.Write("Enter description: ");
                            product.Description = Console.ReadLine();
                            Console.Write("Enter stock quantity: ");
                            product.StockQuantity = Convert.ToInt32(Console.ReadLine());

                            bool productAdded = repository.CreateProduct(product);
                            Console.WriteLine(productAdded ? "Product added successfully." : "Failed to add product.");
                            break;

                        case 2:
                            Customer customer = new Customer();
                            Console.Write("Enter customer name: ");
                            customer.Name = Console.ReadLine();
                            Console.Write("Enter email: ");
                            customer.Email = Console.ReadLine();
                            Console.Write("Enter password: ");
                            customer.Password = Console.ReadLine();

                            bool customerAdded = repository.CreateCustomer(customer);
                            Console.WriteLine(customerAdded ? "Customer added successfully." : "Failed to add customer.");
                            break;

                        case 3:
                            Console.Write("Enter product ID to delete: ");
                            int productIdToDelete = Convert.ToInt32(Console.ReadLine());
                            bool productDeleted = repository.DeleteProduct(productIdToDelete);
                            Console.WriteLine(productDeleted ? "Product deleted successfully." : "Failed to delete product.");
                            break;

                        case 4:
                            Console.Write("Enter customer ID to delete: ");
                            int customerIdToDelete = Convert.ToInt32(Console.ReadLine());
                            bool customerDeleted = repository.DeleteCustomer(customerIdToDelete);
                            Console.WriteLine(customerDeleted ? "Customer deleted successfully." : "Failed to delete customer.");
                            break;

                        case 5:
                            Console.Write("Enter customer ID: ");
                            int custIdForCart = Convert.ToInt32(Console.ReadLine());
                            Customer cartCustomer = new Customer { CustomerId = custIdForCart };

                            // Fetch and display all available products
                            List<Product> availableProducts = repository.GetAllProducts(); // New method to get all products
                            if (availableProducts.Count == 0)
                            {
                                Console.WriteLine("No products available.");
                            }
                            else
                            {
                                Console.WriteLine("Available Products:");
                                foreach (var producti in availableProducts)
                                {
                                    Console.WriteLine($"ID: {producti.ProductId}, Name: {producti.Name}, Price: {producti.Price}, Stock: {producti.StockQuantity}");
                                }

                                // Now ask for product ID
                                Console.Write("Enter product ID to add to cart: ");
                                int prodIdForCart = Convert.ToInt32(Console.ReadLine());
                                Console.Write("Enter quantity: ");
                                int qty = Convert.ToInt32(Console.ReadLine());

                                Product cartProduct = new Product { ProductId = prodIdForCart };

                                bool addedToCart = repository.AddToCart(cartCustomer, cartProduct, qty);
                                Console.WriteLine(addedToCart ? "Product added to cart." : "Failed to add to cart.");
                            }
                            break;


                        case 6:
                            Console.Write("Enter customer ID to view cart: ");
                            int custIdViewCart = Convert.ToInt32(Console.ReadLine());
                            Customer viewCartCustomer = new Customer { CustomerId = custIdViewCart };
                            List<Product> cartItems = repository.GetAllFromCart(viewCartCustomer);

                            if (cartItems.Count == 0)
                                Console.WriteLine("Cart is empty.");
                            else
                            {
                                Console.WriteLine("Products in Cart:");
                                foreach (var item in cartItems)
                                {
                                    Console.WriteLine($"ID: {item.ProductId}, Name: {item.Name}, Price: {item.Price}, Stock: {item.StockQuantity}");
                                }
                            }
                            break;

                        case 7:
                            Console.Write("Enter customer ID: ");
                            int custIdOrder = Convert.ToInt32(Console.ReadLine());
                            Console.Write("Enter number of different products to order: ");
                            int noOfProducts = Convert.ToInt32(Console.ReadLine());

                            Dictionary<Product, int> productQuantitiesByName = new Dictionary<Product, int>();

                            for (int i = 0; i < noOfProducts; i++)
                            {
                                Console.Write($"Enter product name {i + 1}: ");
                                string prodName = Console.ReadLine();

                                // Fetch product by name
                                Product prod = repository.GetProductByName(prodName);
                                if (prod == null)
                                {
                                    Console.WriteLine($"Product '{prodName}' not found. Skipping.");
                                    continue;
                                }

                                Console.Write("Enter quantity: ");
                                int quantity = Convert.ToInt32(Console.ReadLine());

                                productQuantitiesByName.Add(prod, quantity);
                            }

                            Console.Write("Enter shipping address: ");
                            string address = Console.ReadLine();

                            Customer orderCustomerByName = new Customer { CustomerId = custIdOrder };
                            bool orderPlacedByName = repository.PlaceOrder(orderCustomerByName, productQuantitiesByName, address);
                            Console.WriteLine(orderPlacedByName ? "Order placed successfully." : "Failed to place order.");
                            break;


                        case 8:
                            Console.Write("Enter customer ID to view orders: ");
                            int custIdOrders = Convert.ToInt32(Console.ReadLine());
                            List<OrderItem> orders = repository.GetOrdersByCustomer(custIdOrders);

                            if (orders.Count == 0)
                                Console.WriteLine("No orders found for this customer.");
                            else
                            {
                                Console.WriteLine("Order Details:");
                                foreach (var ord in orders)
                                {
                                    Console.WriteLine($"Order Item ID: {ord.OrderItemId}, Order ID: {ord.OrderId}, Product ID: {ord.ProductId}, Quantity: {ord.Quantity}");
                                }
                            }
                            break;

                        case 9:
                            Console.WriteLine("Exiting application. Thank you!");
                            Environment.Exit(0);
                            break;

                        default:
                            Console.WriteLine("Invalid choice.");
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error: {ex.Message}");
                }
            }
        }
    }
}
